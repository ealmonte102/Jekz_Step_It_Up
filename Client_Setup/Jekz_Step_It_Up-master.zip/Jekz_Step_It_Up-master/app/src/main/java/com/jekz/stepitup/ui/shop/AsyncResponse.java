package com.jekz.stepitup.ui.shop;

import org.json.JSONObject;

/**
 * Created by Owner on 12/3/2017.
 */

public interface AsyncResponse {
    void processFinish(JSONObject output);
}