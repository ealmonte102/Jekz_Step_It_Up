package com.jekz.stepitup.data.request;

/**
 * Created by evanalmonte on 12/11/17.
 */

public interface AsyncLoginDelegate {
    void loginResult(String result);
}
