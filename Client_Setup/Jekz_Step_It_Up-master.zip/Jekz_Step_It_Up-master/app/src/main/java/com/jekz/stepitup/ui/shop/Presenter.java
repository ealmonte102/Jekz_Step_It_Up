package com.jekz.stepitup.ui.shop;

/**
 * Created by evanalmonte on 12/7/17.
 */

public interface Presenter {
    void onViewAttached(ShopView view);

    void onViewDetached();
}
